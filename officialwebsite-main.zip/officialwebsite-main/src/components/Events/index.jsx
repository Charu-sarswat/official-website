import React from 'react'
import { Box, Icon, Text, Stack, Flex, Image, Spacer } from '@chakra-ui/react';

const index = () => {
  return (
    <div>
        
    </div>
  )
}

export default index;