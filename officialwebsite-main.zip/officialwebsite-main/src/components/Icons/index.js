export const aiml_icon = "/images/icons/aiml.png";
export const devops_icon = "/images/icons/devops.png";
export const cp_icon = "/images/icons/cp.png";
export const mobile_icon = "/images/icons/appdev.png";
export const web_icon = "/images/icons/webdev.png";
export const cloud_icon = "/images/icons/cloud.png";
export const uiux_icon = "/images/icons/uiux.png";
export const blockchain_icon = "/images/icons/blockchain.svg";